/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import {
  ShieldAlert,
  ShieldCheck,
  Crown,
  Trophy,
  Users,
  Wallet,
  Settings,
  Plus,
  CheckCircle2,
  XCircle,
  FileText,
  Download,
  Search,
  Eye,
  Lock,
  Smartphone,
  X,
  Play,
  RotateCcw,
  Sparkles,
  DollarSign,
  UserCheck,
  Ban,
  Megaphone,
  Image as ImageIcon,
  Upload,
  Radio,
  ArrowLeft,
  KeyRound,
  ExternalLink,
  Trash2,
  Activity,
  Layers,
  Save,
  Check,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useAuth, getRegisteredUsers, saveRegisteredUsers, type StoredAccount } from "@/hooks/useAuth";
import { hasPermission, isOwner, type AppRole } from "@/lib/rbac";
import { getAuditLogs, logAuditEvent, exportAuditLogsAsJson, exportAuditLogsAsCsv, type AuditLogEntry } from "@/lib/audit";
import { inr, fmtDate, DEFAULT_TOURNAMENTS, type Tournament } from "@/lib/game";
import {
  getBroadcasts,
  saveBroadcasts,
  createBroadcast,
  deleteBroadcast,
  type BroadcastNotification,
  type BroadcastType,
} from "@/lib/broadcast";
import {
  getAppBanners,
  saveAppBanners,
  getCategoryCovers,
  saveCategoryCovers,
  processImageFile,
  type CustomBanner,
} from "@/lib/banners-store";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

function AdminPage() {
  const { user, account, role, verifyStaffOrOwnerPasscode, updateAccount, signOut } = useAuth();
  const navigate = useNavigate();

  // Authentication & Passcode check
  const [passcode, setPasscode] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);

  // Active command tab
  const [activeTab, setActiveTab] = useState<
    "overview" | "banners" | "broadcasts" | "tournaments" | "finance" | "users" | "audit"
  >("overview");

  // State data
  const [tournaments, setTournaments] = useState<Tournament[]>(() => {
    if (typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem("dark_esports_tournaments_v1");
        if (raw) return JSON.parse(raw);
      } catch {}
    }
    return DEFAULT_TOURNAMENTS;
  });

  const [banners, setBanners] = useState<CustomBanner[]>(() => getAppBanners());
  const [categoryCovers, setCatCovers] = useState<Record<string, string>>(() => getCategoryCovers());
  const [broadcasts, setBroadcasts] = useState<BroadcastNotification[]>(() => getBroadcasts());
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [auditFilter, setAuditFilter] = useState("");
  const [userList, setUserList] = useState<StoredAccount[]>(() => getRegisteredUsers());

  // Upload state for new banner
  const fileInputRef = useRef<HTMLInputElement>(null);
  const catInputRef = useRef<HTMLInputElement>(null);
  const [selectedCatSlug, setSelectedCatSlug] = useState<string>("freefire");
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [bannerForm, setBannerForm] = useState({
    title: "",
    subtitle: "",
    imageUrl: "",
  });

  // Broadcast composer state
  const [newBroadcast, setNewBroadcast] = useState({
    title: "",
    message: "",
    type: "urgent" as BroadcastType,
    pinned: true,
  });

  // Pending deposits & withdrawals queue
  const [pendingDeposits, setPendingDeposits] = useState(() => [
    { id: "dep-1", userPhone: "9876543210", userName: "DARK KING", amount: 100, utr: "542198762341", time: new Date(Date.now() - 15 * 60000).toISOString() },
    { id: "dep-2", userPhone: "9123456780", userName: "SniperPro99", amount: 50, utr: "439281726543", time: new Date(Date.now() - 45 * 60000).toISOString() },
  ]);

  const [pendingWithdrawals, setPendingWithdrawals] = useState(() => [
    { id: "wth-1", userPhone: "9876543210", userName: "DARK KING", amount: 200, upi: "darkking@okhdfcbank", time: new Date(Date.now() - 30 * 60000).toISOString() },
  ]);

  // App settings state
  const [upiId, setUpiId] = useState("666zishan@fam");
  const [minDeposit, setMinDeposit] = useState(10);
  const [minWithdraw, setMinWithdraw] = useState(50);

  // New Tournament Modal
  const [showNewTourModal, setShowNewTourModal] = useState(false);
  const [newTour, setNewTour] = useState({
    title: "",
    category_id: "b1b94342-32db-4bcb-9db0-02146cae90ae",
    match_type: "Solo",
    map: "Bermuda",
    entry_fee: 20,
    prize_pool: 600,
    per_kill: 5,
    total_slots: 48,
    start_time_offset: 2,
  });

  // Room Credentials Modal
  const [editingRoom, setEditingRoom] = useState<{ id: string; title: string; roomId: string; roomPass: string } | null>(null);

  // User Balance Edit Modal
  const [editingBalanceUser, setEditingBalanceUser] = useState<StoredAccount | null>(null);
  const [addBalanceAmount, setAddBalanceAmount] = useState<number>(100);

  // Refresh lists
  useEffect(() => {
    getAuditLogs().then((logs) => setAuditLogs(logs));
    setUserList(getRegisteredUsers());
    setBanners(getAppBanners());
    setBroadcasts(getBroadcasts());
    setCatCovers(getCategoryCovers());
  }, [activeTab]);

  const [sessionElevated, setSessionElevated] = useState(false);
  const isOwnerAccess = sessionElevated || role === "owner";

  // Passcode verification handler
  const handlePasscodeUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode.trim()) {
      toast.error("Please enter authorization passcode");
      return;
    }
    setIsVerifying(true);
    const res = verifyStaffOrOwnerPasscode(passcode.trim());
    setIsVerifying(false);
    if (res.success) {
      if (res.role === "staff") {
        toast.info("Staff credentials verified. Opening Staff Operations Deck...");
        navigate({ to: "/staff" });
        return;
      }
      toast.success(`Access Granted: Welcome Master Owner!`);
      setSessionElevated(true);
      setPasscode("");
    } else {
      toast.error("Invalid security passcode!");
    }
  };

  // BANNER UPLOAD & MANAGEMENT
  const handleBannerFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      toast.loading("Compressing and preparing image...", { id: "img-upload" });
      const dataUrl = await processImageFile(file, 1200, 0.82);
      setUploadPreview(dataUrl);
      setBannerForm((prev) => ({ ...prev, imageUrl: dataUrl }));
      toast.success("Image ready for publishing!", { id: "img-upload" });
    } catch (err: any) {
      toast.error(err.message || "Failed to process image", { id: "img-upload" });
    }
  };

  const handleAddBanner = () => {
    if (!bannerForm.title.trim()) {
      toast.error("Please enter a title for the banner");
      return;
    }
    const finalImage = bannerForm.imageUrl || uploadPreview;
    if (!finalImage) {
      toast.error("Please upload an image or provide an image URL");
      return;
    }

    const newBannerItem: CustomBanner = {
      id: "banner-" + Date.now().toString(36),
      title: bannerForm.title.trim(),
      subtitle: bannerForm.subtitle.trim() || "Official Dark Esports Event",
      image_url: finalImage,
      active: true,
      sort: banners.length + 1,
    };

    const updated = [newBannerItem, ...banners];
    setBanners(updated);
    saveAppBanners(updated);
    setUploadPreview(null);
    setBannerForm({ title: "", subtitle: "", imageUrl: "" });
    if (fileInputRef.current) fileInputRef.current.value = "";

    void logAuditEvent({
      actorId: user?.id || "admin",
      actorName: account?.username || "Commander",
      actorRole: role,
      action: "HOME_BANNER_UPLOADED",
      entityType: "settings",
      details: `New Home Banner published: "${newBannerItem.title}"`,
      severity: "info",
    });

    toast.success("Banner published! Home screen is updated instantly. 🔥");
  };

  const handleDeleteBanner = (id: string) => {
    const updated = banners.filter((b) => b.id !== id);
    setBanners(updated);
    saveAppBanners(updated);
    toast.success("Banner deleted");
  };

  const handleToggleBanner = (id: string) => {
    const updated = banners.map((b) => (b.id === id ? { ...b, active: !b.active } : b));
    setBanners(updated);
    saveAppBanners(updated);
    toast.success("Banner visibility updated");
  };

  // CATEGORY COVER UPLOAD
  const handleCatFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      toast.loading("Compressing category cover...", { id: "cat-upload" });
      const dataUrl = await processImageFile(file, 800, 0.85);
      const updated = { ...categoryCovers, [selectedCatSlug]: dataUrl };
      setCatCovers(updated);
      saveCategoryCovers(updated);
      toast.success(`Category cover for [${selectedCatSlug.toUpperCase()}] updated!`, { id: "cat-upload" });
    } catch (err: any) {
      toast.error("Failed to process cover image", { id: "cat-upload" });
    }
  };

  // NOTIFICATION BROADCAST MANAGEMENT
  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBroadcast.title.trim() || !newBroadcast.message.trim()) {
      toast.error("Please fill in notification title and message");
      return;
    }

    const created = createBroadcast({
      title: newBroadcast.title,
      message: newBroadcast.message,
      type: newBroadcast.type,
      sender: role === "owner" ? "DARKXPROFESSOR (Owner)" : "Staff Moderator",
      senderRole: role === "owner" ? "owner" : "staff",
      pinned: newBroadcast.pinned,
      actorId: user?.id,
    });

    setBroadcasts(getBroadcasts());
    setNewBroadcast({ title: "", message: "", type: "urgent", pinned: true });
    toast.success("Broadcast sent to all players! 📢");
  };

  const handleDeleteBroadcast = (id: string) => {
    deleteBroadcast(id, account?.username || "Admin");
    setBroadcasts(getBroadcasts());
    toast.success("Broadcast removed");
  };

  // TOURNAMENT CREATION
  const handleCreateTournament = () => {
    if (!newTour.title.trim()) {
      toast.error("Please enter match title");
      return;
    }
    const created: Tournament = {
      id: "tour-" + Math.random().toString(36).slice(2, 9),
      title: newTour.title.trim(),
      category_id: newTour.category_id,
      match_type: newTour.match_type,
      map: newTour.map,
      entry_fee: Number(newTour.entry_fee),
      prize_pool: Number(newTour.prize_pool),
      per_kill: Number(newTour.per_kill),
      total_slots: Number(newTour.total_slots),
      filled_slots: 0,
      start_time: new Date(Date.now() + newTour.start_time_offset * 3600000).toISOString(),
      status: "upcoming",
      rules: "Fair play mandatory. Room ID will be dispatched 15 minutes before start.",
    };

    const updated = [created, ...tournaments];
    setTournaments(updated);
    if (typeof window !== "undefined") {
      localStorage.setItem("dark_esports_tournaments_v1", JSON.stringify(updated));
    }
    setShowNewTourModal(false);
    toast.success("Tournament created and open for registrations!");
  };

  // UPDATE ROOM ID / PASS
  const handleSaveRoom = () => {
    if (!editingRoom) return;
    try {
      localStorage.setItem(
        `dark_room_${editingRoom.id}`,
        JSON.stringify({
          room_id: editingRoom.roomId,
          room_pass: editingRoom.roomPass,
          updated_at: new Date().toISOString(),
        })
      );
      toast.success(`Room ID & Password saved for "${editingRoom.title}"!`);
      setEditingRoom(null);
    } catch {
      toast.error("Failed to save room details");
    }
  };

  // FINANCIALS: APPROVE / REJECT DEPOSIT
  const handleApproveDeposit = (id: string) => {
    const dep = pendingDeposits.find((d) => d.id === id);
    if (!dep) return;

    // Credit player
    const users = getRegisteredUsers();
    const updatedUsers = users.map((u) => {
      if (u.phone === dep.userPhone) {
        return { ...u, deposit_balance: (u.deposit_balance || 0) + dep.amount };
      }
      return u;
    });
    saveRegisteredUsers(updatedUsers);
    setUserList(updatedUsers);
    setPendingDeposits((prev) => prev.filter((d) => d.id !== id));

    void logAuditEvent({
      actorId: user?.id || "admin",
      actorName: account?.username || "Admin",
      actorRole: role,
      action: "WALLET_DEPOSIT_APPROVED",
      entityType: "finance",
      details: `Approved UPI deposit of ₹${dep.amount} for user ${dep.userName} (${dep.userPhone}). UTR: ${dep.utr}`,
      severity: "info",
    });

    toast.success(`Deposit of ₹${dep.amount} approved and credited to ${dep.userName}!`);
  };

  const handleRejectDeposit = (id: string) => {
    setPendingDeposits((prev) => prev.filter((d) => d.id !== id));
    toast.error("Deposit rejected");
  };

  // USER BAN / UNBAN
  const handleToggleUserBan = (phone: string) => {
    const users = getRegisteredUsers();
    const updated = users.map((u) => {
      if (u.phone === phone) {
        const nextBanned = !u.isBanned;
        return { ...u, isBanned: nextBanned, banReason: nextBanned ? "Admin Enforcement" : undefined };
      }
      return u;
    });
    saveRegisteredUsers(updated);
    setUserList(updated);
    toast.success("User account status updated");
  };

  // ADD BALANCE TO USER
  const handleCreditBalance = () => {
    if (!editingBalanceUser || addBalanceAmount <= 0) return;
    const users = getRegisteredUsers();
    const updated = users.map((u) => {
      if (u.phone === editingBalanceUser.phone) {
        return {
          ...u,
          deposit_balance: (u.deposit_balance || 0) + addBalanceAmount,
        };
      }
      return u;
    });
    saveRegisteredUsers(updated);
    setUserList(updated);
    toast.success(`Credited ₹${addBalanceAmount} to ${editingBalanceUser.username}`);
    setEditingBalanceUser(null);
  };

  // 1. RENDER RESTRICTED TERMINAL LOGIN IF NOT ELEVATED
  if (!isOwnerAccess) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 selection:bg-amber-500 selection:text-black">
        {/* Ambient grid background */}
        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

        <div className="relative w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900/90 p-8 shadow-2xl backdrop-blur-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
                <Crown className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-black tracking-wider text-white">CENTRAL COMMAND HQ</h1>
                <p className="text-[11px] font-mono text-slate-400">Restricted Management Clearance</p>
              </div>
            </div>
            <Link
              to="/"
              className="rounded-full p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </div>

          <div className="mb-6 rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs text-amber-300 space-y-1 font-mono">
            <div className="flex items-center gap-2 font-bold uppercase text-amber-400">
              <Lock className="h-4 w-4" /> Military Grade Authorization
            </div>
            <p className="text-[11px] text-slate-400">
              This terminal is strictly restricted to Owner and authorized Staff operators. Enter your master clearance passcode.
            </p>
          </div>

          <form onSubmit={handlePasscodeUnlock} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Authorization Passcode
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder="Enter authorization passcode"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm font-mono text-white placeholder-slate-600 outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  autoFocus
                />
                <KeyRound className="absolute right-3.5 top-3.5 h-4 w-4 text-slate-500" />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isVerifying}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 font-bold uppercase tracking-wider text-black shadow-lg shadow-amber-500/20 hover:from-amber-400 hover:to-orange-500 transition-all"
            >
              {isVerifying ? "Verifying Credentials..." : "Authenticate & Open HQ"}
            </Button>
          </form>

          <div className="mt-6 flex items-center justify-between border-t border-slate-800 pt-4 text-[11px] font-mono text-slate-500">
            <span>DARK ESPORTS v1.0.0</span>
            <Link to="/" className="text-amber-500 hover:underline">
              ← Return to Player Lobby
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // 2. RENDER FULL EXPANSIVE DEDICATED COMMAND CENTER
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-900/95 px-4 py-3 backdrop-blur shadow-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-black shadow-md shadow-amber-500/20">
              <Crown className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black tracking-wider text-white uppercase">
                  DARKXPROFESSOR HQ // COMMAND CENTER
                </h1>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider ${
                    role === "owner"
                      ? "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                      : "bg-blue-500/20 text-blue-400 border border-blue-500/40"
                  }`}
                >
                  {role === "owner" ? "👑 MASTER OWNER" : "🛡️ STAFF MOD"}
                </span>
              </div>
              <p className="text-[11px] font-mono text-slate-400">
                Clearance: Level 5 • AES-256 Encrypted Stream • All Modules Active
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <Link
              to="/"
              className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/80 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-slate-700 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" /> Gamer Lobby
            </Link>

            <button
              onClick={() => {
                updateAccount({ role: "player" });
                navigate({ to: "/" });
                toast.info("Command Session Locked. Elevated role cleared.");
              }}
              className="flex items-center gap-1.5 rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-400 hover:bg-red-500/20 transition-colors"
            >
              <Lock className="h-4 w-4" /> Lock HQ
            </button>
          </div>
        </div>
      </header>

      {/* Navigation Sub-Header */}
      <div className="border-b border-slate-800 bg-slate-900/60 px-4">
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto py-2 no-scrollbar">
          {[
            { id: "overview", label: "📊 Overview", count: null },
            { id: "banners", label: "🖼️ Banners & Assets", count: banners.length },
            { id: "broadcasts", label: "📢 Broadcast Alerts", count: broadcasts.length },
            { id: "tournaments", label: "🏆 Tournaments", count: tournaments.length },
            { id: "finance", label: "💰 UPI & Deposits", count: pendingDeposits.length },
            { id: "users", label: "👥 Users & Roles", count: userList.length },
            { id: "audit", label: "🛡️ Audit Trail", count: auditLogs.length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-amber-500 text-black shadow-md shadow-amber-500/20 font-black"
                  : "text-slate-400 hover:bg-slate-800/70 hover:text-white"
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== null && (
                <span
                  className={`rounded-full px-1.5 py-0.2 text-[10px] ${
                    activeTab === tab.id ? "bg-black/20 text-black font-mono font-bold" : "bg-slate-800 text-slate-400"
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Body */}
      <main className="flex-1 mx-auto w-full max-w-7xl p-4 md:p-6 space-y-6">
        {/* TAB 1: OVERVIEW */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 shadow-sm">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-1">
                  <span>REGISTERED PLAYERS</span>
                  <Users className="h-4 w-4 text-blue-400" />
                </div>
                <div className="text-2xl font-black text-white">{userList.length}</div>
                <div className="text-[11px] text-slate-500 mt-1">PBKDF2 salted passwords</div>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 shadow-sm">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-1">
                  <span>ACTIVE MATCHES</span>
                  <Trophy className="h-4 w-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-white">{tournaments.length}</div>
                <div className="text-[11px] text-amber-500 mt-1">Free Fire, BGMI, Clash Squad</div>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 shadow-sm">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-1">
                  <span>PENDING DEPOSITS</span>
                  <Wallet className="h-4 w-4 text-green-400" />
                </div>
                <div className="text-2xl font-black text-white">{pendingDeposits.length}</div>
                <div className="text-[11px] text-green-500 mt-1">Requires manual or UTR check</div>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 shadow-sm">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold mb-1">
                  <span>ACTIVE BANNERS</span>
                  <ImageIcon className="h-4 w-4 text-purple-400" />
                </div>
                <div className="text-2xl font-black text-white">{banners.length}</div>
                <div className="text-[11px] text-purple-400 mt-1">Real-time live on Home</div>
              </div>
            </div>

            {/* Quick Action Dock */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/40 p-5 space-y-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                Quick Command Dispatch
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button
                  onClick={() => setActiveTab("banners")}
                  className="flex items-center gap-2.5 rounded-xl border border-slate-700 bg-slate-800/80 p-3 text-left hover:border-amber-500 transition-colors"
                >
                  <Upload className="h-5 w-5 text-amber-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Upload Banner</div>
                    <div className="text-[10px] text-slate-400">Change home carousel</div>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab("broadcasts")}
                  className="flex items-center gap-2.5 rounded-xl border border-slate-700 bg-slate-800/80 p-3 text-left hover:border-amber-500 transition-colors"
                >
                  <Megaphone className="h-5 w-5 text-red-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Send Broadcast</div>
                    <div className="text-[10px] text-slate-400">Urgent player alert</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTab("tournaments");
                    setShowNewTourModal(true);
                  }}
                  className="flex items-center gap-2.5 rounded-xl border border-slate-700 bg-slate-800/80 p-3 text-left hover:border-amber-500 transition-colors"
                >
                  <Plus className="h-5 w-5 text-green-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">New Scrim Match</div>
                    <div className="text-[10px] text-slate-400">Add FF or BGMI tournament</div>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab("finance")}
                  className="flex items-center gap-2.5 rounded-xl border border-slate-700 bg-slate-800/80 p-3 text-left hover:border-amber-500 transition-colors"
                >
                  <CheckCircle2 className="h-5 w-5 text-blue-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Approve Deposits</div>
                    <div className="text-[10px] text-slate-400">{pendingDeposits.length} pending UPI requests</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Recent System Activity / Audit Snippet */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                  Live Security Audit Stream (SHA-256 Chained)
                </h3>
                <button
                  onClick={() => setActiveTab("audit")}
                  className="text-xs font-bold text-amber-400 hover:underline"
                >
                  View All Logs →
                </button>
              </div>

              <div className="space-y-2">
                {auditLogs.slice(0, 4).map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`h-2 w-2 rounded-full ${
                          log.severity === "critical"
                            ? "bg-red-500 animate-ping"
                            : log.severity === "warning"
                            ? "bg-amber-500"
                            : "bg-blue-500"
                        }`}
                      />
                      <span className="font-mono text-slate-400 font-bold">[{log.action}]</span>
                      <span className="text-slate-200">{log.details}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">{fmtDate(log.timestamp)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: BANNERS & VISUAL ASSETS (DIRECT UPLOAD & REPLACE) */}
        {activeTab === "banners" && (
          <div className="space-y-6">
            {/* Header info */}
            <div className="rounded-3xl border border-slate-800 bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 p-5">
              <h2 className="text-base font-black uppercase text-white flex items-center gap-2">
                <ImageIcon className="h-5 w-5 text-amber-400" /> Banners & Image Studio
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Admin & Owner panel se direct image upload karein. Uploaded banners aur category covers turant Gamer Home screen pe update ho jate hain!
              </p>
            </div>

            {/* Direct Upload New Banner Box */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                <Upload className="h-4 w-4" /> Upload New Home Carousel Banner
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Banner Heading / Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. GRAND FREE FIRE FINALS ₹10,000"
                      value={bannerForm.title}
                      onChange={(e) => setBannerForm({ ...bannerForm, title: e.target.value })}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs text-white outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Subtitle / Promo Tagline
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Register squad before 8 PM • Cash instant reward"
                      value={bannerForm.subtitle}
                      onChange={(e) => setBannerForm({ ...bannerForm, subtitle: e.target.value })}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs text-white outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Upload Image File (Device se select karein)
                    </label>
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept="image/*"
                      onChange={handleBannerFileSelect}
                      className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-500 file:text-black hover:file:bg-amber-400 cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">
                      Or Paste Image Web URL
                    </label>
                    <input
                      type="url"
                      placeholder="https://..."
                      value={bannerForm.imageUrl}
                      onChange={(e) => {
                        setBannerForm({ ...bannerForm, imageUrl: e.target.value });
                        setUploadPreview(e.target.value);
                      }}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs text-white outline-none focus:border-amber-500"
                    />
                  </div>

                  <Button
                    onClick={handleAddBanner}
                    className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-xs"
                  >
                    Publish Banner to Home Screen 🔥
                  </Button>
                </div>

                {/* Live Preview Card */}
                <div className="flex flex-col justify-center items-center border border-dashed border-slate-700 rounded-2xl p-4 bg-slate-950/50">
                  <span className="text-[11px] font-mono text-slate-400 mb-2">LIVE CAROUSEL PREVIEW</span>
                  {uploadPreview || bannerForm.imageUrl ? (
                    <div className="relative w-full h-44 rounded-2xl overflow-hidden shadow-lg border border-slate-800">
                      <img
                        src={uploadPreview || bannerForm.imageUrl}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
                      <div className="absolute bottom-3 left-3 text-white">
                        <div className="text-sm font-extrabold">{bannerForm.title || "Banner Title"}</div>
                        <div className="text-[11px] text-slate-300">
                          {bannerForm.subtitle || "Subtitle tagline will appear here"}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-slate-500 text-xs">
                      <ImageIcon className="mx-auto h-10 w-10 text-slate-600 mb-2" />
                      Select an image file above to see live preview
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Active Banners List */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Current Active Banners ({banners.length})
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {banners.map((b) => (
                  <div
                    key={b.id}
                    className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-md flex flex-col justify-between"
                  >
                    <div className="relative h-32 w-full">
                      <img src={b.image_url} alt={b.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                      <div className="absolute bottom-2 left-3 text-white">
                        <div className="text-xs font-bold">{b.title}</div>
                        <div className="text-[10px] text-slate-300 truncate max-w-[200px]">{b.subtitle}</div>
                      </div>
                      <span
                        className={`absolute top-2 right-2 rounded-full px-2 py-0.5 text-[9px] font-bold ${
                          b.active ? "bg-green-500/20 text-green-400 border border-green-500/40" : "bg-red-500/20 text-red-400"
                        }`}
                      >
                        {b.active ? "LIVE" : "HIDDEN"}
                      </span>
                    </div>

                    <div className="p-3 flex items-center justify-between border-t border-slate-800 text-xs">
                      <button
                        onClick={() => handleToggleBanner(b.id)}
                        className="text-slate-400 hover:text-white font-semibold"
                      >
                        {b.active ? "Hide" : "Show"}
                      </button>

                      <button
                        onClick={() => handleDeleteBanner(b.id)}
                        className="flex items-center gap-1 text-red-400 hover:text-red-300 font-semibold"
                      >
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Category Imagery Customizer */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                    Category Cover Artwork Customizer
                  </h3>
                  <p className="text-xs text-slate-400">
                    Replace thumbnail artwork for Free Fire, BGMI, Clash Squad, and Lone Wolf
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { slug: "freefire", name: "Free Fire Battle Royale" },
                  { slug: "bgmi", name: "BGMI Erangel / Miramar" },
                  { slug: "clash", name: "Free Fire Clash Squad" },
                  { slug: "lonewolf", name: "Lone Wolf 1v1" },
                ].map((cat) => (
                  <div
                    key={cat.slug}
                    className="rounded-2xl border border-slate-800 bg-slate-950 p-3 space-y-2 flex flex-col justify-between"
                  >
                    <div className="relative aspect-video rounded-xl overflow-hidden border border-slate-800">
                      <img
                        src={categoryCovers[cat.slug] || ""}
                        alt={cat.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="text-xs font-bold text-white truncate">{cat.name}</div>
                    <button
                      onClick={() => {
                        setSelectedCatSlug(cat.slug);
                        catInputRef.current?.click();
                      }}
                      className="w-full py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-[11px] font-bold text-amber-400 hover:bg-slate-700"
                    >
                      Change Cover
                    </button>
                  </div>
                ))}
              </div>
              <input
                type="file"
                ref={catInputRef}
                accept="image/*"
                onChange={handleCatFileSelect}
                className="hidden"
              />
            </div>
          </div>
        )}

        {/* TAB 3: BROADCAST ALERTS & NOTIFICATIONS */}
        {activeTab === "broadcasts" && (
          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-800 bg-gradient-to-r from-red-500/10 via-slate-900 to-slate-900 p-5">
              <h2 className="text-base font-black uppercase text-white flex items-center gap-2">
                <Megaphone className="h-5 w-5 text-red-400" /> Push Notification & Broadcast Dispatch
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Admin aur Owner yahan se sabhi users ko push alerts aur ticker marquee bhej sakte hain. Players ke navbar bell icon aur home ticker me instant broadcast display hoga.
              </p>
            </div>

            {/* Broadcast Composer */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                <Radio className="h-4 w-4" /> Send Real-Time Broadcast
              </h3>

              <form onSubmit={handleSendBroadcast} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Broadcast Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 🔥 Weekend Mega Tournament Registration Open!"
                      value={newBroadcast.title}
                      onChange={(e) => setNewBroadcast({ ...newBroadcast, title: e.target.value })}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs text-white outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Notification Urgency Type
                    </label>
                    <select
                      value={newBroadcast.type}
                      onChange={(e) => setNewBroadcast({ ...newBroadcast, type: e.target.value as any })}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs text-white outline-none focus:border-amber-500"
                    >
                      <option value="urgent">🔥 Urgent Alert (Critical)</option>
                      <option value="tournament">🏆 Tournament Match Alert</option>
                      <option value="wallet">💰 Cash / UPI Deposit Notice</option>
                      <option value="info">ℹ️ General Information</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Broadcast Message Body
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Enter detailed announcement message..."
                    value={newBroadcast.message}
                    onChange={(e) => setNewBroadcast({ ...newBroadcast, message: e.target.value })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-xs text-white outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex items-center justify-between border-t border-slate-800 pt-3">
                  <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newBroadcast.pinned}
                      onChange={(e) => setNewBroadcast({ ...newBroadcast, pinned: e.target.checked })}
                      className="h-4 w-4 rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-950"
                    />
                    <span>Pin to Home Screen Marquee / Top Alert Bar</span>
                  </label>

                  <Button
                    type="submit"
                    className="h-10 px-6 bg-red-600 hover:bg-red-500 text-white font-bold uppercase text-xs"
                  >
                    Broadcast to All Players 📢
                  </Button>
                </div>
              </form>
            </div>

            {/* Sent Broadcasts History */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Sent Broadcasts ({broadcasts.length})
              </h3>

              <div className="space-y-3">
                {broadcasts.map((b) => (
                  <div
                    key={b.id}
                    className="rounded-2xl border border-slate-800 bg-slate-950 p-4 flex flex-col md:flex-row md:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                            b.type === "urgent"
                              ? "bg-red-500/20 text-red-400"
                              : b.type === "tournament"
                              ? "bg-amber-500/20 text-amber-400"
                              : "bg-blue-500/20 text-blue-400"
                          }`}
                        >
                          {b.type}
                        </span>
                        {b.pinned && (
                          <span className="rounded bg-yellow-500/20 text-yellow-400 px-2 py-0.5 text-[10px] font-bold">
                            PINNED TICKER
                          </span>
                        )}
                        <span className="text-[10px] text-slate-500 font-mono">{fmtDate(b.created_at)}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white">{b.title}</h4>
                      <p className="text-xs text-slate-400">{b.message}</p>
                      <div className="text-[11px] text-slate-500">
                        Dispatched by: <span className="text-amber-400 font-semibold">{b.sender}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteBroadcast(b.id)}
                      className="flex items-center gap-1 rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-400 hover:bg-red-500/20 shrink-0 self-start md:self-center"
                    >
                      <Trash2 className="h-4 w-4" /> Remove
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: TOURNAMENTS & MATCH CONTROL */}
        {activeTab === "tournaments" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-black uppercase text-white">Tournament & Scrims Control</h2>
                <p className="text-xs text-slate-400">Add tournaments, update room ID & passwords, declare winners</p>
              </div>
              <Button
                onClick={() => setShowNewTourModal(true)}
                className="bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-xs"
              >
                <Plus className="h-4 w-4 mr-1" /> Create Match
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tournaments.map((t) => (
                <div
                  key={t.id}
                  className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 space-y-3 shadow-sm"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-amber-400 tracking-wider font-mono">
                        {t.map} • {t.match_type}
                      </span>
                      <h4 className="text-sm font-bold text-white">{t.title}</h4>
                    </div>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                        t.status === "upcoming"
                          ? "bg-blue-500/20 text-blue-400"
                          : t.status === "ongoing"
                          ? "bg-green-500/20 text-green-400 animate-pulse"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {t.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    <div className="rounded-xl bg-slate-950 p-2 border border-slate-800">
                      <div className="text-[10px] text-slate-500">ENTRY</div>
                      <div className="font-bold text-amber-400">{inr(t.entry_fee)}</div>
                    </div>
                    <div className="rounded-xl bg-slate-950 p-2 border border-slate-800">
                      <div className="text-[10px] text-slate-500">PRIZE</div>
                      <div className="font-bold text-green-400">{inr(t.prize_pool)}</div>
                    </div>
                    <div className="rounded-xl bg-slate-950 p-2 border border-slate-800">
                      <div className="text-[10px] text-slate-500">PER KILL</div>
                      <div className="font-bold text-white">{inr(t.per_kill)}</div>
                    </div>
                    <div className="rounded-xl bg-slate-950 p-2 border border-slate-800">
                      <div className="text-[10px] text-slate-500">SLOTS</div>
                      <div className="font-bold text-slate-200">
                        {t.filled_slots}/{t.total_slots}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-800 pt-3 text-xs">
                    <button
                      onClick={() =>
                        setEditingRoom({
                          id: t.id,
                          title: t.title,
                          roomId: "",
                          roomPass: "",
                        })
                      }
                      className="text-amber-400 hover:underline font-bold flex items-center gap-1"
                    >
                      <KeyRound className="h-3.5 w-3.5" /> Dispatch Room ID & Pass
                    </button>

                    <select
                      value={t.status}
                      onChange={(e) => {
                        const updated = tournaments.map((item) =>
                          item.id === t.id ? { ...item, status: e.target.value } : item
                        );
                        setTournaments(updated);
                        localStorage.setItem("dark_esports_tournaments_v1", JSON.stringify(updated));
                        toast.success(`Match status set to [${e.target.value}]`);
                      }}
                      className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1 text-xs text-white"
                    >
                      <option value="upcoming">Upcoming</option>
                      <option value="ongoing">Ongoing</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: FINANCE & UPI APPROVALS */}
        {activeTab === "finance" && (
          <div className="space-y-6">
            {/* UPI Settings */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Official UPI Receiver Gateway
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Official UPI ID</label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Min Deposit (₹)</label>
                  <input
                    type="number"
                    value={minDeposit}
                    onChange={(e) => setMinDeposit(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Min Withdrawal (₹)</label>
                  <input
                    type="number"
                    value={minWithdraw}
                    onChange={(e) => setMinWithdraw(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>
            </div>

            {/* Pending Deposits */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                  Pending UPI Deposits ({pendingDeposits.length})
                </h3>
                <span className="text-xs text-slate-400">Verify UTR and credit wallet in 1-tap</span>
              </div>

              {pendingDeposits.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  Sabhi deposits cleared hain. Koi pending request nahi hai.
                </div>
              ) : (
                <div className="space-y-3">
                  {pendingDeposits.map((dep) => (
                    <div
                      key={dep.id}
                      className="rounded-2xl border border-slate-800 bg-slate-950 p-4 flex flex-col md:flex-row md:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-white">
                          {dep.userName} ({dep.userPhone})
                        </div>
                        <div className="text-xs text-slate-400">
                          Amount: <span className="font-bold text-green-400">₹{dep.amount}</span> • UTR:{" "}
                          <span className="font-mono text-amber-400 font-bold">{dep.utr}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">{fmtDate(dep.time)}</div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleApproveDeposit(dep.id)}
                          className="flex items-center gap-1 rounded-xl bg-green-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-green-500"
                        >
                          <Check className="h-4 w-4" /> Approve & Credit
                        </button>
                        <button
                          onClick={() => handleRejectDeposit(dep.id)}
                          className="flex items-center gap-1 rounded-xl bg-red-600/20 text-red-400 px-3 py-1.5 text-xs font-bold hover:bg-red-600/30"
                        >
                          <X className="h-4 w-4" /> Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 6: USERS & ROLES */}
        {activeTab === "users" && (
          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                    Registered Gamers & Roles ({userList.length})
                  </h3>
                  <p className="text-xs text-slate-400">Manage player bans, balances, and role credentials</p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-800 text-slate-400 uppercase font-mono text-[10px]">
                    <tr>
                      <th className="py-2.5">User</th>
                      <th className="py-2.5">Mobile</th>
                      <th className="py-2.5">Role</th>
                      <th className="py-2.5">Balances (Dep/Win)</th>
                      <th className="py-2.5">Status</th>
                      <th className="py-2.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {userList.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-800/30">
                        <td className="py-3 font-semibold text-white">
                          {u.avatar} {u.username}
                        </td>
                        <td className="py-3 font-mono text-slate-300">{u.phone}</td>
                        <td className="py-3">
                          <span
                            className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                              u.role === "owner"
                                ? "bg-amber-500/20 text-amber-400"
                                : u.role === "staff"
                                ? "bg-blue-500/20 text-blue-400"
                                : "bg-slate-800 text-slate-300"
                            }`}
                          >
                            {u.role}
                          </span>
                        </td>
                        <td className="py-3 text-slate-300">
                          ₹{u.deposit_balance} / ₹{u.winning_balance}
                        </td>
                        <td className="py-3">
                          {u.isBanned ? (
                            <span className="rounded bg-red-500/20 text-red-400 px-2 py-0.5 text-[10px] font-bold">
                              BANNED
                            </span>
                          ) : (
                            <span className="rounded bg-green-500/20 text-green-400 px-2 py-0.5 text-[10px] font-bold">
                              ACTIVE
                            </span>
                          )}
                        </td>
                        <td className="py-3 text-right space-x-2">
                          <button
                            onClick={() => setEditingBalanceUser(u)}
                            className="rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 px-2.5 py-1 font-semibold"
                          >
                            Credit Balance
                          </button>
                          <button
                            onClick={() => handleToggleUserBan(u.phone)}
                            className={`rounded-lg px-2.5 py-1 font-semibold ${
                              u.isBanned
                                ? "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                                : "bg-red-500/20 text-red-400 hover:bg-red-500/30"
                            }`}
                          >
                            {u.isBanned ? "Unban" : "Ban"}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: AUDIT TRAIL */}
        {activeTab === "audit" && (
          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                    Tamper-Evident SHA-256 Audit Trail ({auditLogs.length})
                  </h3>
                  <p className="text-xs text-slate-400">Cryptographically verifiable actions log</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      exportAuditLogsAsJson(auditLogs);
                      toast.success("Audit trail downloaded as JSON");
                    }}
                    className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-bold text-white hover:bg-slate-700"
                  >
                    <Download className="h-3.5 w-3.5" /> JSON
                  </button>
                  <button
                    onClick={() => {
                      exportAuditLogsAsCsv(auditLogs);
                      toast.success("Audit trail downloaded as CSV");
                    }}
                    className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-bold text-white hover:bg-slate-700"
                  >
                    <Download className="h-3.5 w-3.5" /> CSV
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                {auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="rounded-xl border border-slate-800 bg-slate-950 p-3 space-y-1 text-xs font-mono"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="font-bold text-amber-400">{log.action}</span>
                      <span>{fmtDate(log.timestamp)}</span>
                    </div>
                    <div className="text-slate-200">{log.details}</div>
                    <div className="text-[10px] text-slate-500 truncate">
                      Actor: {log.actorName} ({log.actorRole}) • Hash: {log.hash}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* MODAL: CREATE MATCH */}
      {showNewTourModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85" onClick={() => setShowNewTourModal(false)}>
          <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Create New Tournament</h3>
              <button onClick={() => setShowNewTourModal(false)} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Match Title</label>
                <input
                  type="text"
                  value={newTour.title}
                  onChange={(e) => setNewTour({ ...newTour, title: e.target.value })}
                  placeholder="e.g. Solo Night Rush #102"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Entry Fee (₹)</label>
                  <input
                    type="number"
                    value={newTour.entry_fee}
                    onChange={(e) => setNewTour({ ...newTour, entry_fee: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Prize Pool (₹)</label>
                  <input
                    type="number"
                    value={newTour.prize_pool}
                    onChange={(e) => setNewTour({ ...newTour, prize_pool: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Per Kill (₹)</label>
                  <input
                    type="number"
                    value={newTour.per_kill}
                    onChange={(e) => setNewTour({ ...newTour, per_kill: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Total Slots</label>
                  <input
                    type="number"
                    value={newTour.total_slots}
                    onChange={(e) => setNewTour({ ...newTour, total_slots: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                  />
                </div>
              </div>

              <Button onClick={handleCreateTournament} className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase">
                Launch Tournament
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DISPATCH ROOM ID */}
      {editingRoom && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85" onClick={() => setEditingRoom(null)}>
          <div className="w-full max-w-sm rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Dispatch Room Details</h3>
              <button onClick={() => setEditingRoom(null)} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400">Match: {editingRoom.title}</p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Custom Room ID</label>
                <input
                  type="text"
                  placeholder="e.g. 5421980"
                  value={editingRoom.roomId}
                  onChange={(e) => setEditingRoom({ ...editingRoom, roomId: e.target.value })}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Room Password</label>
                <input
                  type="text"
                  placeholder="e.g. 1234"
                  value={editingRoom.roomPass}
                  onChange={(e) => setEditingRoom({ ...editingRoom, roomPass: e.target.value })}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white font-mono"
                />
              </div>

              <Button onClick={handleSaveRoom} className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase">
                Save & Broadcast to Players
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CREDIT BALANCE */}
      {editingBalanceUser && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85" onClick={() => setEditingBalanceUser(null)}>
          <div className="w-full max-w-sm rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Credit Player Wallet</h3>
              <button onClick={() => setEditingBalanceUser(null)} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="text-xs text-slate-300">
              Player: <span className="font-bold text-white">{editingBalanceUser.username}</span> ({editingBalanceUser.phone})
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Credit Amount (₹)</label>
              <input
                type="number"
                value={addBalanceAmount}
                onChange={(e) => setAddBalanceAmount(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white font-bold"
              />
            </div>

            <Button onClick={handleCreditBalance} className="w-full bg-green-600 hover:bg-green-500 text-white font-bold uppercase text-xs">
              Confirm Add ₹{addBalanceAmount}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
