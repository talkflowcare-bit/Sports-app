# Loading improvements
- [x] Reduce repeat requests and reuse loaded match data.
- [x] Reduce image download sizes without replacing artwork.
- [x] Check signed-in Home → category → match → Home and regression tests.
- [x] Limit blocking startup to 3 seconds without bypassing account checks.
- [x] Verify fast launch and delayed-auth behavior.