import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export const STARTUP_WAIT_MS = 3000;
type AuthCtx = { user: User | null; session: Session | null; loading: boolean; startupTimedOut: boolean };
const Ctx = createContext<AuthCtx>({ user: null, session: null, loading: true, startupTimedOut: false });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [startupTimedOut, setStartupTimedOut] = useState(false);

  useEffect(() => {
    let active = true;
    let authEventReceived = false;
    const startupTimer = setTimeout(() => {
      if (active) setStartupTimedOut(true);
    }, STARTUP_WAIT_MS);
    const { data } = supabase.auth.onAuthStateChange((_e, s) => {
      if (!active) return;
      clearTimeout(startupTimer);
      authEventReceived = true;
      setSession(s);
      setLoading(false);
    });
    supabase.auth.getSession().then(({ data: d }) => {
      if (!active || authEventReceived) return;
      clearTimeout(startupTimer);
      setSession(d.session);
      setLoading(false);
    }).catch(() => {
      clearTimeout(startupTimer);
      if (active && !authEventReceived) setLoading(false);
    });
    return () => {
      active = false;
      clearTimeout(startupTimer);
      data.subscription.unsubscribe();
    };
  }, []);

  return <Ctx.Provider value={{ session, user: session?.user ?? null, loading, startupTimedOut }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
