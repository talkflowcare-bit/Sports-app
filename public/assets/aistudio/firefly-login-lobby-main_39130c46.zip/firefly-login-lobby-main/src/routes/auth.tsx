import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Mail, Lock, User, Gift, Gamepad2, Hash, Phone, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { GameLoader } from "@/components/GameLoader";
import { APP_NAME, errMsg } from "@/lib/game";
import { bannerImage as banner } from "@/lib/game";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Login – DARK ESPORTS" },
      { name: "description", content: "Login or create your DARK ESPORTS account with your Free Fire in-game name to join tournaments." },
      { property: "og:title", content: "Login – DARK ESPORTS" },
      { property: "og:description", content: "Login or create your DARK ESPORTS account to join Free Fire tournaments." },
    ],
  }),
  component: AuthPage,
});

function Field({ icon: Icon, label, right, ...props }: { icon: typeof Mail; label: string; right?: React.ReactNode } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{label}</span>
      <div className="relative">
        <Icon className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-primary" />
        <input
          {...props}
          className="w-full rounded-xl border border-border bg-background/80 py-3 pl-11 pr-11 text-sm outline-none transition focus:border-primary focus:glow-ring"
        />
        {right && <div className="absolute right-3 top-1/2 -translate-y-1/2">{right}</div>}
      </div>
    </label>
  );
}

const empty = { email: "", password: "", username: "", ign: "", ffuid: "", phone: "", refer: "" };

function AuthPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [busy, setBusy] = useState(false);
  const [show, setShow] = useState(false);
  const [f, setF] = useState(empty);
  const { user, loading, startupTimedOut } = useAuth();
  const navigate = useNavigate();
  const set = (k: keyof typeof empty) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  useEffect(() => {
    if (user) navigate({ to: "/" });
  }, [user, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email: f.email.trim(), password: f.password });
        if (error) throw error;
      } else {
        if (f.username.trim().length < 3) throw new Error("Full name kam se kam 3 letters ka ho");
        if (f.ign.trim().length < 3) throw new Error("Apna Free Fire IN-GAME NAME daalo");
        if (!/^\d{8,14}$/.test(f.ffuid.trim())) throw new Error("Free Fire UID 8-14 digits ka hona chahiye");
        if (!/^[6-9]\d{9}$/.test(f.phone.trim())) throw new Error("Sahi 10 digit mobile number daalo");
        const { data, error } = await supabase.auth.signUp({
          email: f.email.trim(),
          password: f.password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { username: f.username.trim(), ff_ign: f.ign.trim(), ff_uid: f.ffuid.trim(), phone: f.phone.trim(), refer_code: f.refer.trim() },
          },
        });
        if (error) throw error;
        if (!data.session) {
          toast.success("Account ban gaya! Email check karke confirm karo, phir login karo.");
          setMode("login");
        }
      }
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) toast.error(errMsg(r.error));
  };

  if ((loading && !startupTimedOut) || user) return <GameLoader label="Checking account" />;

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background p-5">
      <img src={banner} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/80 to-background" />
      {busy && <GameLoader label={mode === "login" ? "Logging in" : "Creating account"} />}
      <div className="relative w-full max-w-sm animate-pop rounded-3xl border border-border bg-header px-6 py-8 shadow-card backdrop-blur">
        <div className="text-center text-3xl font-extrabold uppercase tracking-[2px] text-primary">{APP_NAME}</div>
        <p className="mb-5 mt-1 text-center text-xs text-muted-foreground">
          {mode === "login" ? "Welcome back, Survivor! 🔥" : "Free Fire tournament khelo, cash jeeto"}
        </p>
        <div className="mb-5 grid grid-cols-2 rounded-xl border border-border bg-background/60 p-1 text-xs font-bold uppercase">
          {(["login", "signup"] as const).map((m) => (
            <button key={m} type="button" onClick={() => setMode(m)} className={`rounded-lg py-2 transition ${mode === m ? "bg-gradient-primary text-primary-foreground" : "text-muted-foreground"}`}>
              {m === "login" ? "Login" : "Sign Up"}
            </button>
          ))}
        </div>
        <form onSubmit={submit}>
          {mode === "signup" && (
            <>
              <Field icon={User} label="Full Name" placeholder="Rahul Kumar" value={f.username} onChange={set("username")} required />
              <Field icon={Gamepad2} label="Free Fire In-Game Name" placeholder="DARKツKING" maxLength={24} value={f.ign} onChange={set("ign")} required />
              <Field icon={Hash} label="Free Fire UID" placeholder="1234567890" inputMode="numeric" maxLength={14} value={f.ffuid} onChange={(e) => setF({ ...f, ffuid: e.target.value.replace(/\D/g, "") })} required />
              <Field icon={Phone} label="Mobile Number" placeholder="9876543210" inputMode="tel" maxLength={10} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/\D/g, "") })} required />
            </>
          )}
          <Field icon={Mail} label="Email" type="email" placeholder="you@gmail.com" value={f.email} onChange={set("email")} required />
          <Field
            icon={Lock}
            label="Password"
            type={show ? "text" : "password"}
            placeholder="Min 6 characters"
            minLength={6}
            value={f.password}
            onChange={set("password")}
            required
            right={
              <button type="button" aria-label="Show password" onClick={() => setShow(!show)} className="text-muted-foreground">
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            }
          />
          {mode === "signup" && <Field icon={Gift} label="Refer Code (optional)" placeholder="ABC123" value={f.refer} onChange={set("refer")} />}
          <div className="mt-2">
            <Button variant="game" type="submit" disabled={busy}>
              {mode === "login" ? "Login to Battle" : "Create Account • Get ₹10"}
            </Button>
          </div>
        </form>
        <div className="my-4 flex items-center gap-3 text-[11px] text-muted-foreground">
          <div className="h-px flex-1 bg-border" />OR<div className="h-px flex-1 bg-border" />
        </div>
        <Button variant="gameOutline" type="button" onClick={google}>Continue with Google</Button>
      </div>
    </div>
  );
}
