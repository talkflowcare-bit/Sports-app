import { QueryClient } from "@tanstack/react-query";
import { cleanup, render, screen, act } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { Session } from "@supabase/supabase-js";

const auth = vi.hoisted(() => ({ getSession: vi.fn(), onAuthStateChange: vi.fn() }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { auth } }));
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import { categoriesQuery, bannersQuery, settingsQuery, tournamentsQuery } from "@/lib/game";

afterEach(() => { cleanup(); vi.clearAllMocks(); vi.useRealTimers(); });

function SessionStatus() {
  const { user, loading, startupTimedOut } = useAuth();
  return <output>{loading ? startupTimedOut ? "startup-ready-auth-pending" : "pending" : user?.id ?? "signed-out"}</output>;
}

describe("Loading regressions", () => {
  it("ends blocking startup at exactly 3 seconds while keeping unresolved authentication pending", async () => {
    vi.useFakeTimers();
    let resolveSession: ((value: { data: { session: Session | null } }) => void) | undefined;
    auth.getSession.mockImplementation(() => new Promise((resolve) => { resolveSession = resolve; }));
    auth.onAuthStateChange.mockReturnValue({ data: { subscription: { unsubscribe: vi.fn() } } });
    render(<AuthProvider><SessionStatus /></AuthProvider>);
    await act(async () => { vi.advanceTimersByTime(2999); });
    expect(screen.getByText("pending")).toBeInTheDocument();
    await act(async () => { vi.advanceTimersByTime(1); });
    expect(screen.getByText("startup-ready-auth-pending")).toBeInTheDocument();
    await act(async () => { resolveSession?.({ data: { session: { user: { id: "late-player" } } as Session } }); });
    expect(screen.getByText("late-player")).toBeInTheDocument();
  });

  it("reuses public data on repeat navigation but refetches invalidated data", async () => {
    const client = new QueryClient();
    for (const options of [categoriesQuery, bannersQuery, settingsQuery, tournamentsQuery()]) {
      const queryFn = vi.fn().mockResolvedValue([]);
      if (typeof options.staleTime !== "number") throw new Error("Expected numeric query freshness");
      const query = { queryKey: Array.from(options.queryKey), staleTime: options.staleTime, queryFn };
      await client.fetchQuery(query);
      await client.fetchQuery(query);
      expect(queryFn).toHaveBeenCalledTimes(1);
      await client.invalidateQueries({ queryKey: options.queryKey });
      await client.fetchQuery(query);
      expect(queryFn).toHaveBeenCalledTimes(2);
    }
    client.clear();
  });

  it("does not overwrite a new sign-in with a delayed initial session read", async () => {
    let resolveSession: ((value: { data: { session: null } }) => void) | undefined;
    let authEvent: ((event: string, session: Session | null) => void) | undefined;
    auth.getSession.mockImplementation(() => new Promise((resolve) => { resolveSession = resolve; }));
    auth.onAuthStateChange.mockImplementation((callback) => {
      authEvent = callback;
      return { data: { subscription: { unsubscribe: vi.fn() } } };
    });
    render(<AuthProvider><SessionStatus /></AuthProvider>);
    expect(screen.getByText("pending")).toBeInTheDocument();
    await act(async () => { authEvent?.("SIGNED_IN", { user: { id: "player-1" } } as Session); });
    expect(screen.getByText("player-1")).toBeInTheDocument();
    await act(async () => { resolveSession?.({ data: { session: null } }); });
    expect(screen.getByText("player-1")).toBeInTheDocument();
  });

  it("stops waiting when the initial session lookup fails", async () => {
    auth.getSession.mockRejectedValue(new Error("connection failed"));
    auth.onAuthStateChange.mockReturnValue({ data: { subscription: { unsubscribe: vi.fn() } } });
    render(<AuthProvider><SessionStatus /></AuthProvider>);
    expect(await screen.findByText("signed-out")).toBeInTheDocument();
  });
});