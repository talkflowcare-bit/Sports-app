import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import banner from "@/assets/banner.webp";
import ff from "@/assets/cat-freefire.webp";
import bgmi from "@/assets/cat-bgmi.webp";
import clash from "@/assets/cat-clash.webp";

export const APP_NAME = "DARK ESPORTS";

export const categoryImages: Record<string, string> = { freefire: ff, bgmi, clash, lonewolf: ff };
export const bannerImage = banner;
export const catImg = (slug: string, url?: string | null) => url || categoryImages[slug] || ff;

export const inr = (n: number | string | null | undefined) => `₹${Number(n ?? 0).toLocaleString("en-IN")}`;

export function errMsg(e: unknown) {
  const m = (e as { message?: string })?.message ?? "Something went wrong";
  return m;
}

export const profileQuery = (uid: string) =>
  queryOptions({
    queryKey: ["profile", uid],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", uid).single();
      if (error) throw error;
      return data;
    },
  });

export const settingsQuery = queryOptions({
  queryKey: ["settings"],
  staleTime: 60_000,
  queryFn: async () => {
    const { data, error } = await supabase.from("app_settings").select("*").eq("id", 1).single();
    if (error) throw error;
    return data;
  },
});

export const categoriesQuery = queryOptions({
  queryKey: ["categories"],
  staleTime: 300_000,
  queryFn: async () => {
    const { data, error } = await supabase.from("categories").select("*").order("sort");
    if (error) throw error;
    return data;
  },
});

export const bannersQuery = queryOptions({
  queryKey: ["banners"],
  staleTime: 300_000,
  queryFn: async () => {
    const { data, error } = await supabase.from("banners").select("*").order("sort");
    if (error) throw error;
    return data;
  },
});

const TOUR_COLS =
  "id, category_id, title, map, match_type, entry_fee, prize_pool, per_kill, start_time, total_slots, filled_slots, status, rules";

export type Tournament = {
  id: string; category_id: string; title: string; map: string; match_type: string;
  entry_fee: number; prize_pool: number; per_kill: number; start_time: string;
  total_slots: number; filled_slots: number; status: string; rules: string | null;
};

export const tournamentsQuery = (categoryId?: string) =>
  queryOptions({
    queryKey: ["tournaments", categoryId ?? "all"],
    staleTime: 15_000,
    queryFn: async () => {
      let q = supabase.from("tournaments").select(TOUR_COLS).order("start_time");
      if (categoryId) q = q.eq("category_id", categoryId);
      const { data, error } = await q;
      if (error) throw error;
      return data as Tournament[];
    },
  });

export const tournamentQuery = (id: string) =>
  queryOptions({
    queryKey: ["tournament", id],
    staleTime: 15_000,
    queryFn: async () => {
      const { data, error } = await supabase.from("tournaments").select(TOUR_COLS).eq("id", id).single();
      if (error) throw error;
      return data as Tournament;
    },
  });

export const myJoinsQuery = (uid: string) =>
  queryOptions({
    queryKey: ["myjoins", uid],
    staleTime: 15_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("match_joins")
        .select("tournament_id, slot, game_name, kills, rank, prize")
        .eq("user_id", uid);
      if (error) throw error;
      return data;
    },
  });

export const txnsQuery = (uid: string) =>
  queryOptions({
    queryKey: ["txns", uid],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(50);
      if (error) throw error;
      return data;
    },
  });

export function countdown(iso: string, now: number) {
  const d = new Date(iso).getTime() - now;
  if (d <= 0) return "Started";
  const h = Math.floor(d / 3.6e6), m = Math.floor((d % 3.6e6) / 6e4), s = Math.floor((d % 6e4) / 1000);
  const pad = (x: number) => String(x).padStart(2, "0");
  return h >= 24 ? `${Math.floor(h / 24)}d ${h % 24}h` : `${pad(h)}:${pad(m)}:${pad(s)}`;
}

export const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
