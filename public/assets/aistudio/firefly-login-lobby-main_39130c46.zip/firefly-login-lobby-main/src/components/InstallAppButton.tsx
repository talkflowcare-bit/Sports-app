import { Download } from "lucide-react";
import { usePwaInstall } from "@/hooks/usePwaInstall";

export function InstallAppButton() {
  const { canInstall, installed, install } = usePwaInstall();

  if (installed || !canInstall) return null;

  return (
    <button
      onClick={() => void install()}
      className="flex items-center gap-1 rounded-full bg-primary px-3 py-1.5 text-[12px] font-bold text-primary-foreground shadow-card transition-transform active:scale-95"
    >
      <Download className="h-3.5 w-3.5" /> Install App
    </button>
  );
}
