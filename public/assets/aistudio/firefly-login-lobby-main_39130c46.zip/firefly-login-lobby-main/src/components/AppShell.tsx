import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, type ReactNode } from "react";
import { Home, Wallet, Trophy, Headset, User, Bell } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { APP_NAME, inr, profileQuery } from "@/lib/game";
import { GameLoader } from "@/components/GameLoader";
import { InstallAppButton } from "@/components/InstallAppButton";

const nav = [
  { to: "/", label: "Home", icon: Home },
  { to: "/wallet", label: "Wallet", icon: Wallet },
  { to: "/rank", label: "Rank", icon: Trophy },
  { to: "/help", label: "Help", icon: Headset },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function AppShell({ children, title, hideNav }: { children: ReactNode; title?: string; hideNav?: boolean }) {
  const { user, loading, startupTimedOut } = useAuth();
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if ((!loading || startupTimedOut) && !user) navigate({ to: "/auth" });
  }, [loading, startupTimedOut, user, navigate]);

  const { data: profile } = useQuery({ ...profileQuery(user?.id ?? ""), enabled: !!user });
  const total = profile ? Number(profile.winning_balance) + Number(profile.deposit_balance) + Number(profile.bonus_balance) : 0;

  if (loading || !user) return <GameLoader label="Entering lobby" />;

  return (
    <div className="mx-auto min-h-screen max-w-md bg-background pb-28">
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-border bg-header px-5 py-4 shadow-card backdrop-blur">
        <Link to="/" className="text-lg font-extrabold uppercase tracking-wider text-primary">
          {title ?? APP_NAME}
        </Link>
        <div className="flex items-center gap-3">
          <InstallAppButton />
          <span className="flex items-center gap-1 rounded-lg border border-success px-2 py-1 text-[11px] font-bold text-success">
            <span className="h-1.5 w-1.5 animate-live rounded-full bg-success" /> LIVE
          </span>
          <Link to="/profile" aria-label="Notifications" className="text-muted-foreground">
            <Bell className="h-5 w-5" />
          </Link>
          <Link
            to="/wallet"
            className="flex items-center gap-1 rounded-full border border-warning/40 bg-warning/10 px-3 py-1.5 text-[13px] font-bold text-warning"
          >
            <Wallet className="h-4 w-4" /> {inr(total)}
          </Link>
        </div>
      </header>
      <main className="animate-pop">{children}</main>
      {!hideNav && (
        <nav className="fixed bottom-4 left-1/2 z-50 flex w-[calc(100%-2rem)] max-w-[26rem] -translate-x-1/2 justify-around rounded-2xl border border-border bg-header py-2.5 shadow-card backdrop-blur">
          {nav.map(({ to, label, icon: Icon }) => {
            const active = to === "/" ? path === "/" : path.startsWith(to);
            return (
              <Link
                key={to}
                to={to}
                className={`flex flex-col items-center gap-0.5 px-2 text-[11px] font-semibold transition-colors ${active ? "text-primary" : "text-muted-foreground"}`}
              >
                <Icon className={`h-5 w-5 ${active ? "-translate-y-0.5" : ""} transition-transform`} />
                {label}
              </Link>
            );
          })}
        </nav>
      )}
    </div>
  );
}
