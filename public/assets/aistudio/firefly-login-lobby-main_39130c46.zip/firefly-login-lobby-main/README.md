# Firefly Login Lobby

Is me dekho Jo login system h usme like wo IN-GAME NAME WAgaira bhi likhwao or loading animation wagaira bhi accha kr ke final kro or ff ki images use karo or mujhe complete krke apk do

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/f7d42a21-0ea0-4506-a2f2-595f8fde9e3e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
