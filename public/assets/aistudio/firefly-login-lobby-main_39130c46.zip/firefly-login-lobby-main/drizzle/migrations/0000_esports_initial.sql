create type public.app_role as enum ('owner','staff','player');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null default 'Player',
  avatar text not null default '👦',
  uid_code text not null default upper(substr(md5(random()::text),1,8)),
  winning_balance numeric not null default 0,
  deposit_balance numeric not null default 0,
  bonus_balance numeric not null default 0,
  matches_played int not null default 0,
  matches_won int not null default 0,
  total_kills int not null default 0,
  total_earnings numeric not null default 0,
  refer_code text not null default upper(substr(md5(random()::text),1,6)),
  referred_by text,
  ff_ign text not null default '',
  ff_uid text not null default '',
  phone text not null default '',
  created_at timestamptz not null default now()
);
grant select on public.profiles to authenticated;
grant update (username, avatar, ff_ign, ff_uid, phone) on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "own profile read" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username, bonus_balance, referred_by, ff_ign, ff_uid, phone)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'username',''), nullif(new.raw_user_meta_data->>'full_name',''), split_part(new.email,'@',1)), 10,
          nullif(new.raw_user_meta_data->>'refer_code',''),
          left(coalesce(new.raw_user_meta_data->>'ff_ign',''),24),
          left(regexp_replace(coalesce(new.raw_user_meta_data->>'ff_uid',''),'[^0-9]','','g'),14),
          left(regexp_replace(coalesce(new.raw_user_meta_data->>'phone',''),'[^0-9]','','g'),10));
  insert into public.user_roles (user_id, role) values (new.id, 'player');
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.app_settings (
  id int primary key default 1,
  app_name text not null default 'DARK ESPORTS',
  upi_id text not null default '666zishan@fam',
  min_deposit numeric not null default 10,
  min_withdraw numeric not null default 50,
  max_withdraw numeric not null default 5000,
  notice text not null default 'Welcome to DARK ESPORTS! Join daily tournaments and win real cash.',
  support_whatsapp text not null default '',
  support_instagram text not null default '',
  support_telegram text not null default '',
  rules text not null default '1. No hacks or emulators.
2. Join room 10 minutes before start.
3. Teaming is strictly prohibited.
4. Screenshot of result required on dispute.'
);
grant select on public.app_settings to anon, authenticated;
grant all on public.app_settings to service_role;
alter table public.app_settings enable row level security;
create policy "settings public" on public.app_settings for select to anon, authenticated using (true);
insert into public.app_settings (id) values (1);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  image_url text,
  sort int not null default 0,
  active boolean not null default true
);
grant select on public.categories to anon, authenticated;
grant all on public.categories to service_role;
alter table public.categories enable row level security;
create policy "cat public" on public.categories for select to anon, authenticated using (active);

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,
  image_url text,
  sort int not null default 0,
  active boolean not null default true
);
grant select on public.banners to anon, authenticated;
grant all on public.banners to service_role;
alter table public.banners enable row level security;
create policy "banner public" on public.banners for select to anon, authenticated using (active);

create table public.tournaments (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories(id) on delete cascade,
  title text not null,
  map text not null default 'Bermuda',
  match_type text not null default 'Solo',
  entry_fee numeric not null default 0,
  prize_pool numeric not null default 0,
  per_kill numeric not null default 0,
  start_time timestamptz not null,
  total_slots int not null default 48,
  filled_slots int not null default 0,
  status text not null default 'upcoming',
  room_id text,
  room_pass text,
  rules text,
  created_at timestamptz not null default now()
);
grant select (id, category_id, title, map, match_type, entry_fee, prize_pool, per_kill, start_time, total_slots, filled_slots, status, rules, created_at) on public.tournaments to anon, authenticated;
grant all on public.tournaments to service_role;
alter table public.tournaments enable row level security;
create policy "tour public" on public.tournaments for select to anon, authenticated using (true);

create table public.match_joins (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  user_id uuid not null,
  slot int not null,
  game_name text not null,
  kills int not null default 0,
  rank int,
  prize numeric not null default 0,
  created_at timestamptz not null default now(),
  unique (tournament_id, slot)
);
grant select on public.match_joins to authenticated;
grant all on public.match_joins to service_role;
alter table public.match_joins enable row level security;
create policy "joins read own" on public.match_joins for select to authenticated using (auth.uid() = user_id);

create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  kind text not null,
  amount numeric not null,
  status text not null default 'pending',
  utr text,
  upi_id text,
  note text,
  created_at timestamptz not null default now()
);
grant select on public.transactions to authenticated;
grant all on public.transactions to service_role;
alter table public.transactions enable row level security;
create policy "own txns" on public.transactions for select to authenticated using (auth.uid() = user_id);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);
grant select on public.notifications to authenticated;
grant all on public.notifications to service_role;
alter table public.notifications enable row level security;
create policy "notif read" on public.notifications for select to authenticated using (true);

create or replace function public.join_tournament(_tournament_id uuid, _names text[])
returns void language plpgsql security definer set search_path = public as $$
declare t record; p record; cost numeric; n int; use_bonus numeric; use_dep numeric; use_win numeric; s int; i int := 1;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  n := coalesce(array_length(_names,1),0);
  if n < 1 or n > 4 then raise exception 'Select 1 to 4 players'; end if;
  select * into t from tournaments where id = _tournament_id for update;
  if t is null or t.status <> 'upcoming' then raise exception 'Match not open for joining'; end if;
  if t.filled_slots + n > t.total_slots then raise exception 'Not enough slots left'; end if;
  if exists (select 1 from match_joins where tournament_id=_tournament_id and user_id=auth.uid()) then raise exception 'You already joined this match'; end if;
  cost := t.entry_fee * n;
  select * into p from profiles where id = auth.uid() for update;
  if p.bonus_balance + p.deposit_balance + p.winning_balance < cost then raise exception 'Insufficient balance. Please add cash.'; end if;
  use_bonus := least(p.bonus_balance, cost * 0.1);
  use_dep := least(p.deposit_balance, cost - use_bonus);
  use_win := cost - use_bonus - use_dep;
  if use_win > p.winning_balance then use_bonus := least(p.bonus_balance, cost - use_dep - p.winning_balance); use_win := cost - use_bonus - use_dep; end if;
  update profiles set bonus_balance = bonus_balance - use_bonus, deposit_balance = deposit_balance - use_dep,
    winning_balance = winning_balance - use_win, matches_played = matches_played + 1 where id = auth.uid();
  for s in 1..t.total_slots loop
    exit when i > n;
    if not exists (select 1 from match_joins where tournament_id=_tournament_id and slot=s) then
      insert into match_joins (tournament_id, user_id, slot, game_name) values (_tournament_id, auth.uid(), s, trim(_names[i]));
      i := i + 1;
    end if;
  end loop;
  update tournaments set filled_slots = filled_slots + n where id = _tournament_id;
  if cost > 0 then
    insert into transactions (user_id, kind, amount, status, note) values (auth.uid(), 'join', cost, 'success', 'Joined ' || t.title);
  end if;
end; $$;

create or replace function public.get_room(_tournament_id uuid)
returns table(room_id text, room_pass text) language sql stable security definer set search_path = public as $$
  select t.room_id, t.room_pass from tournaments t
  where t.id = _tournament_id and exists (select 1 from match_joins j where j.tournament_id = t.id and j.user_id = auth.uid())
$$;

create or replace function public.request_deposit(_amount numeric, _utr text)
returns void language plpgsql security definer set search_path = public as $$
declare mn numeric;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  select min_deposit into mn from app_settings where id=1;
  if _amount < mn then raise exception 'Minimum deposit is ₹%', mn; end if;
  if length(trim(coalesce(_utr,''))) < 6 then raise exception 'Enter a valid UTR number'; end if;
  if exists (select 1 from transactions where utr = trim(_utr) and kind='deposit') then raise exception 'This UTR is already used'; end if;
  insert into transactions (user_id, kind, amount, status, utr) values (auth.uid(), 'deposit', _amount, 'pending', trim(_utr));
end; $$;

create or replace function public.request_withdraw(_amount numeric, _upi text)
returns void language plpgsql security definer set search_path = public as $$
declare s record; w numeric;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  select * into s from app_settings where id=1;
  if _amount < s.min_withdraw or _amount > s.max_withdraw then raise exception 'Withdraw limit ₹% to ₹%', s.min_withdraw, s.max_withdraw; end if;
  if position('@' in coalesce(_upi,'')) = 0 then raise exception 'Enter a valid UPI ID'; end if;
  if exists (select 1 from transactions where user_id=auth.uid() and kind='withdraw' and created_at::date = now()::date) then raise exception 'Only 1 withdrawal allowed per day'; end if;
  select winning_balance into w from profiles where id=auth.uid() for update;
  if w < _amount then raise exception 'Insufficient winning balance'; end if;
  update profiles set winning_balance = winning_balance - _amount where id = auth.uid();
  insert into transactions (user_id, kind, amount, status, upi_id) values (auth.uid(), 'withdraw', _amount, 'pending', trim(_upi));
end; $$;

create or replace function public.get_leaderboard()
returns table(username text, avatar text, matches_won int, total_kills int, total_earnings numeric)
language sql stable security definer set search_path = public as $$
  select username, avatar, matches_won, total_kills, total_earnings from profiles
  order by total_earnings desc, matches_won desc, total_kills desc limit 50
$$;

create or replace function public.get_match_players(_tournament_id uuid)
returns table(slot int, game_name text, kills int, rank int, prize numeric)
language sql stable security definer set search_path = public as $$
  select slot, game_name, kills, rank, prize from match_joins where tournament_id = _tournament_id order by slot
$$;

revoke execute on function public.join_tournament, public.request_deposit, public.request_withdraw, public.get_room from anon;
grant execute on function public.join_tournament, public.request_deposit, public.request_withdraw, public.get_room, public.get_leaderboard, public.get_match_players to authenticated;

insert into public.categories (name, slug, sort) values
 ('Free Fire', 'freefire', 1), ('BGMI', 'bgmi', 2), ('Free Fire Clash Squad', 'clash', 3), ('Lone Wolf', 'lonewolf', 4);
insert into public.banners (title, subtitle, sort) values
 ('MEGA WEEKEND CUP', 'Prize Pool ₹5,000 • Join Now', 1),
 ('DAILY SCRIMS', 'Play every evening at 8 PM', 2);
insert into public.tournaments (category_id, title, map, match_type, entry_fee, prize_pool, per_kill, start_time, total_slots, filled_slots)
select c.id, v.title, v.map, v.mt, v.fee, v.pool, v.pk, now() + v.offs, v.slots, v.filled
from public.categories c join (values
 ('freefire','Solo Night Battle #101','Bermuda','Solo',20,600,5,interval '3 hours',48,0),
 ('freefire','Duo Rush #55','Purgatory','Duo',30,1000,8,interval '1 day',48,0),
 ('freefire','Squad Showdown #12','Kalahari','Squad',50,2000,10,interval '2 days',48,0),
 ('bgmi','Erangel Classic #21','Erangel','Squad',40,1500,8,interval '5 hours',100,0),
 ('bgmi','Miramar Solo #8','Miramar','Solo',15,500,4,interval '1 day',100,0),
 ('clash','CS 4v4 Arena #33','Bermuda','Squad',25,400,0,interval '6 hours',8,0),
 ('lonewolf','Lone Wolf 1v1 #9','Iron Cage','Solo',10,18,0,interval '2 hours',2,0)
) as v(slug,title,map,mt,fee,pool,pk,offs,slots,filled) on c.slug = v.slug;
insert into public.notifications (title, body) values ('Welcome to DARK ESPORTS', 'Get ₹10 bonus on signup. Join your first match today!');