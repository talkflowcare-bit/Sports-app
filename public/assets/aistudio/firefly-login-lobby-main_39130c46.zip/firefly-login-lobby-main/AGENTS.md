<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Reuse React Query tournament list data for category/detail initial data, preserving its update timestamp; this avoids navigation waterfalls without extending freshness.
- Give stable public lists longer freshness than live tournament data, keep balances at default freshness, and invalidate affected match keys after joining; this reduces redundant downloads without hiding financial updates.
- Use optimized WebP copies of the existing artwork in the app; preserve original source artwork for future changes.
- Bound the startup auth splash independently of authentication resolution; show sign-in after the deadline without treating an unresolved session as authenticated or cancelling late session recovery.
