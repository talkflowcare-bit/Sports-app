import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export const STARTUP_WAIT_MS = 2500;
export const DEMO_UID = "00000000-0000-0000-0000-000000000001";
export const LOCAL_USER_KEY = "dark_esports_user";
export const REGISTERED_USERS_KEY = "dark_esports_registered_users";

export type StoredAccount = {
  id: string;
  phone: string;
  password?: string;
  username: string;
  ff_ign: string;
  ff_uid: string;
  refer?: string;
  winning_balance: number;
  deposit_balance: number;
  bonus_balance: number;
  matches_played: number;
  matches_won: number;
  total_kills: number;
  total_earnings: number;
  avatar: string;
  created_at: string;
};

export function getRegisteredUsers(): StoredAccount[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(REGISTERED_USERS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveRegisteredUsers(users: StoredAccount[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(users));
  } catch {}
}

export function getActiveUser(): StoredAccount | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LOCAL_USER_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function toSupabaseUser(account: StoredAccount): User {
  return {
    id: account.id,
    app_metadata: { provider: "phone" },
    user_metadata: {
      username: account.username,
      ff_ign: account.ff_ign,
      ff_uid: account.ff_uid,
      phone: account.phone,
    },
    aud: "authenticated",
    created_at: account.created_at,
    email: `${account.phone}@darkesports.app`,
    phone: account.phone,
    role: "authenticated",
    updated_at: new Date().toISOString(),
  };
}

export const DEMO_ACCOUNT: StoredAccount = {
  id: DEMO_UID,
  phone: "9876543210",
  password: "password123",
  username: "DARKツKING",
  ff_ign: "DARKツKING",
  ff_uid: "1234567890",
  refer: "DARK100",
  winning_balance: 150,
  deposit_balance: 50,
  bonus_balance: 20,
  matches_played: 14,
  matches_won: 5,
  total_kills: 32,
  total_earnings: 750,
  avatar: "🔥",
  created_at: new Date().toISOString(),
};

type AuthCtx = {
  user: User | null;
  account: StoredAccount | null;
  session: Session | null;
  loading: boolean;
  startupTimedOut: boolean;
  registerUser: (data: { phone: string; password: string; ign: string; ffuid: string; refer?: string }) => StoredAccount;
  loginUser: (phone: string, password: string) => { success: boolean; error?: string };
  updateAccount: (patch: Partial<StoredAccount>) => void;
  signOut: () => Promise<void>;
  setLocalUser: (u: Partial<StoredAccount> & { phone: string }) => void;
};

const Ctx = createContext<AuthCtx>({
  user: null,
  account: null,
  session: null,
  loading: true,
  startupTimedOut: false,
  registerUser: () => DEMO_ACCOUNT,
  loginUser: () => ({ success: false }),
  updateAccount: () => {},
  signOut: async () => {},
  setLocalUser: () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [account, setAccount] = useState<StoredAccount | null>(() => {
    if (typeof window !== "undefined") {
      const p = new URLSearchParams(window.location.search);
      if (p.has("autostart")) return DEMO_ACCOUNT;
      return getActiveUser();
    }
    return null;
  });

  const [session, setSession] = useState<Session | null>(() => {
    if (typeof window !== "undefined") {
      const p = new URLSearchParams(window.location.search);
      if (p.has("autostart")) {
        return {
          access_token: "demo-token",
          refresh_token: "demo-refresh",
          expires_in: 3600,
          token_type: "bearer",
          user: toSupabaseUser(DEMO_ACCOUNT),
        };
      }
      const stored = getActiveUser();
      if (stored) {
        return {
          access_token: "local-token",
          refresh_token: "local-refresh",
          expires_in: 86400,
          token_type: "bearer",
          user: toSupabaseUser(stored),
        };
      }
    }
    return null;
  });

  const [loading, setLoading] = useState(false);
  const [startupTimedOut, setStartupTimedOut] = useState(true);

  const applyActiveAccount = (acc: StoredAccount | null) => {
    setAccount(acc);
    if (acc) {
      const user = toSupabaseUser(acc);
      setSession({
        access_token: "local-token",
        refresh_token: "local-refresh",
        expires_in: 86400,
        token_type: "bearer",
        user,
      });
      try {
        localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(acc));
      } catch {}
    } else {
      setSession(null);
      try {
        localStorage.removeItem(LOCAL_USER_KEY);
      } catch {}
    }
    setLoading(false);
  };

  const registerUser = (data: { phone: string; password: string; ign: string; ffuid: string; refer?: string }): StoredAccount => {
    const list = getRegisteredUsers();
    const cleanPhone = data.phone.trim().replace(/\D/g, "");

    // Generate valid UUID for compatibility
    const newId = "00000000-0000-4000-8000-" + cleanPhone.padStart(12, "0");

    const newAcc: StoredAccount = {
      id: newId,
      phone: cleanPhone,
      password: data.password,
      username: data.ign.trim(),
      ff_ign: data.ign.trim(),
      ff_uid: data.ffuid.trim(),
      refer: data.refer?.trim() || "",
      winning_balance: 0,
      deposit_balance: 0,
      bonus_balance: 10, // ₹10 welcome bonus
      matches_played: 0,
      matches_won: 0,
      total_kills: 0,
      total_earnings: 0,
      avatar: "🔥",
      created_at: new Date().toISOString(),
    };

    const updatedList = list.filter((u) => u.phone !== cleanPhone);
    updatedList.push(newAcc);
    saveRegisteredUsers(updatedList);
    applyActiveAccount(newAcc);

    // Also attempt remote sync in background
    try {
      supabase.auth.signUp({
        email: `${cleanPhone}@darkesports.app`,
        password: data.password,
        options: {
          data: {
            username: newAcc.username,
            ff_ign: newAcc.ff_ign,
            ff_uid: newAcc.ff_uid,
            phone: cleanPhone,
            refer_code: newAcc.refer,
          },
        },
      }).catch(() => {});
    } catch {}

    return newAcc;
  };

  const loginUser = (phone: string, password: string): { success: boolean; error?: string } => {
    const cleanPhone = phone.trim().replace(/\D/g, "");
    const list = getRegisteredUsers();
    const found = list.find((u) => u.phone === cleanPhone);

    if (found) {
      if (found.password && found.password !== password) {
        return { success: false, error: "Galat password! Sahi password daalo." };
      }
      applyActiveAccount(found);
      return { success: true };
    }

    // If not in registered list, create instant account or allow login
    const autoAcc: StoredAccount = {
      id: "00000000-0000-4000-8000-" + cleanPhone.padStart(12, "0"),
      phone: cleanPhone,
      password,
      username: `Player_${cleanPhone.slice(-4)}`,
      ff_ign: `DARK_${cleanPhone.slice(-4)}`,
      ff_uid: cleanPhone,
      winning_balance: 0,
      deposit_balance: 0,
      bonus_balance: 10,
      matches_played: 0,
      matches_won: 0,
      total_kills: 0,
      total_earnings: 0,
      avatar: "🔥",
      created_at: new Date().toISOString(),
    };

    list.push(autoAcc);
    saveRegisteredUsers(list);
    applyActiveAccount(autoAcc);
    return { success: true };
  };

  const updateAccount = (patch: Partial<StoredAccount>) => {
    if (!account) return;
    const updated: StoredAccount = { ...account, ...patch };
    applyActiveAccount(updated);

    const list = getRegisteredUsers().map((u) => (u.phone === updated.phone ? updated : u));
    saveRegisteredUsers(list);
  };

  const setLocalUser = (u: Partial<StoredAccount> & { phone: string }) => {
    const cleanPhone = u.phone.trim().replace(/\D/g, "");
    const existing = getActiveUser();
    const acc: StoredAccount = {
      id: u.id || existing?.id || ("00000000-0000-4000-8000-" + cleanPhone.padStart(12, "0")),
      phone: cleanPhone,
      password: u.password || existing?.password || "123456",
      username: u.username || u.ff_ign || existing?.username || `Player_${cleanPhone.slice(-4)}`,
      ff_ign: u.ff_ign || existing?.ff_ign || "DARKツKING",
      ff_uid: u.ff_uid || existing?.ff_uid || "1234567890",
      refer: u.refer || existing?.refer || "",
      winning_balance: u.winning_balance ?? existing?.winning_balance ?? 150,
      deposit_balance: u.deposit_balance ?? existing?.deposit_balance ?? 50,
      bonus_balance: u.bonus_balance ?? existing?.bonus_balance ?? 20,
      matches_played: u.matches_played ?? existing?.matches_played ?? 14,
      matches_won: u.matches_won ?? existing?.matches_won ?? 5,
      total_kills: u.total_kills ?? existing?.total_kills ?? 32,
      total_earnings: u.total_earnings ?? existing?.total_earnings ?? 750,
      avatar: u.avatar || existing?.avatar || "🔥",
      created_at: u.created_at || existing?.created_at || new Date().toISOString(),
    };
    applyActiveAccount(acc);
  };

  const signOut = async () => {
    applyActiveAccount(null);
    try {
      await supabase.auth.signOut().catch(() => {});
    } catch {}
  };

  useEffect(() => {
    let active = true;

    const params = new URLSearchParams(window.location.search);
    if (params.has("autostart")) {
      applyActiveAccount(DEMO_ACCOUNT);
      return;
    }

    const current = getActiveUser();
    if (current) {
      applyActiveAccount(current);
    } else {
      setLoading(false);
    }
  }, []);

  return (
    <Ctx.Provider
      value={{
        user: session?.user ?? null,
        account,
        session,
        loading,
        startupTimedOut,
        registerUser,
        loginUser,
        updateAccount,
        signOut,
        setLocalUser,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
