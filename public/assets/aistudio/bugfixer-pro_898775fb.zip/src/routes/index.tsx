import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Megaphone } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { MatchCard } from "@/components/MatchCard";
import { useAuth } from "@/hooks/useAuth";
import { bannerImage, bannersQuery, catImg, categoriesQuery, myJoinsQuery, settingsQuery, tournamentsQuery } from "@/lib/game";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "DARK ESPORTS – Play Tournaments, Win Cash" },
      { name: "description", content: "Join Free Fire & BGMI tournaments daily on DARK ESPORTS and win real cash prizes." },
      { property: "og:title", content: "DARK ESPORTS – Play Tournaments, Win Cash" },
      { property: "og:description", content: "Join Free Fire & BGMI tournaments daily and win real cash prizes." },
    ],
  }),
  component: Home,
});

function Home() {
  const { user } = useAuth();
  const { data: banners = [] } = useQuery(bannersQuery);
  const { data: cats = [] } = useQuery(categoriesQuery);
  const { data: settings } = useQuery(settingsQuery);
  const { data: tours = [] } = useQuery(tournamentsQuery());
  const { data: joins = [] } = useQuery({ ...myJoinsQuery(user?.id ?? ""), enabled: !!user });
  const [tab, setTab] = useState<"upcoming" | "ongoing" | "completed">("upcoming");
  const [bi, setBi] = useState(0);

  useEffect(() => {
    if (banners.length < 2) return;
    const i = setInterval(() => setBi((x) => (x + 1) % banners.length), 3500);
    return () => clearInterval(i);
  }, [banners.length]);

  const joinedIds = new Set(joins.map((j) => j.tournament_id));
  const mine = tours.filter((t) => joinedIds.has(t.id) && t.status === tab);
  const slugOf = (cid: string) => cats.find((c) => c.id === cid)?.slug ?? "freefire";
  const countFor = (cid: string) => tours.filter((t) => t.category_id === cid && t.status === "upcoming").length;

  return (
    <AppShell>
      <div className="space-y-6 px-4 pt-4">
        {settings?.notice && (
          <div className="flex items-center gap-2 overflow-hidden rounded-xl bg-accent px-3 py-2 text-xs font-medium text-accent-foreground">
            <Megaphone className="h-4 w-4 shrink-0 text-primary" />
            <span className="truncate">{settings.notice}</span>
          </div>
        )}

        {banners.length > 0 && (
          <div className="relative h-40 overflow-hidden rounded-2xl shadow-card">
            <img src={banners[bi]?.image_url || bannerImage} alt={banners[bi]?.title} fetchPriority="high" decoding="async" width={1280} height={640} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-dark" />
            <div className="absolute bottom-4 left-4 text-background">
              <div className="text-xl font-extrabold">{banners[bi]?.title}</div>
              <div className="text-xs opacity-90">{banners[bi]?.subtitle}</div>
            </div>
            <div className="absolute bottom-3 right-4 flex gap-1">
              {banners.map((b, i) => (
                <span key={b.id} className={`h-1.5 rounded-full transition-all ${i === bi ? "w-5 bg-primary" : "w-1.5 bg-background/70"}`} />
              ))}
            </div>
          </div>
        )}

        <section>
          <h2 className="mb-3 text-base font-bold">My Matches</h2>
          <div className="mb-3 flex gap-2 rounded-xl bg-muted p-1">
            {(["upcoming", "ongoing", "completed"] as const).map((k) => (
              <button
                key={k}
                onClick={() => setTab(k)}
                className={`flex-1 rounded-lg py-2 text-xs font-semibold capitalize transition ${tab === k ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground"}`}
              >
                {k === "completed" ? "Results" : k}
              </button>
            ))}
          </div>
          {mine.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border py-6 text-center text-xs text-muted-foreground">
              No {tab === "completed" ? "results" : `${tab} matches`} yet. Join a match below!
            </div>
          ) : (
            <div className="space-y-3">
              {mine.map((t) => <MatchCard key={t.id} t={t} slug={slugOf(t.category_id)} joined />)}
            </div>
          )}
        </section>

        <section>
          <h2 className="mb-3 text-base font-bold">Esports Categories</h2>
          <div className="grid grid-cols-2 gap-3">
            {cats.map((c) => (
              <Link key={c.id} to="/category/$slug" params={{ slug: c.slug }} className="group relative aspect-square overflow-hidden rounded-2xl shadow-card">
                <img src={catImg(c.slug, c.image_url)} alt={c.name} loading="lazy" width={816} height={816} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-dark" />
                <div className="absolute bottom-3 left-3 right-3 text-background">
                  <div className="text-sm font-bold leading-tight">{c.name}</div>
                  <div className="text-[11px] opacity-90">{countFor(c.id)} matches open</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
