import { Download } from "lucide-react";
import { usePwaInstall } from "@/hooks/usePwaInstall";
import { toast } from "sonner";

export function InstallAppButton() {
  const { canInstall, installed, install } = usePwaInstall();

  const handleAction = async () => {
    // If browser supports and triggered PWA prompt, offer install
    if (canInstall) {
      const outcome = await install();
      if (outcome) {
        toast.success("DARK ESPORTS installed successfully! 🔥");
        return;
      }
    }

    // Direct APK download for Android users
    toast.info("Downloading DARK ESPORTS APK...");
    const link = document.createElement("a");
    link.href = "/DarkEsports.apk";
    link.download = "DarkEsports.apk";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <button
      onClick={handleAction}
      aria-label="Download APK or Install App"
      className="flex items-center gap-1 rounded-full bg-primary px-3 py-1.5 text-[12px] font-bold text-primary-foreground shadow-card transition-transform active:scale-95"
    >
      <Download className="h-3.5 w-3.5" /> {installed ? "Download APK" : "Install App"}
    </button>
  );
}
